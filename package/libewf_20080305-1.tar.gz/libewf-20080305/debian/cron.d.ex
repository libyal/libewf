#
# Regular cron jobs for the libewf package
#
0 4	* * *	root	libewf_maintenance
