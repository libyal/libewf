liblibewf 20080305 libewf (>> 20080305-0), libewf (<< 20080305-99)
