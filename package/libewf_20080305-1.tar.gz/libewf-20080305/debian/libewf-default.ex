# Defaults for libewf initscript
# sourced by /etc/init.d/libewf
# installed at /etc/default/libewf by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
