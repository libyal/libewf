?package(libewf):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="libewf" command="/usr/bin/libewf"
